from django.http import HttpResponseRedirect
from django.shortcuts import render,redirect
from .models import Books,Student
from .forms import BookForm, StudentForm, LoginForm
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib.auth.forms import UserCreationForm
# Create your views here.
#def index(request):
#   return render(request, 'library/index.html',{
#        'books':Books.objects.all()
#        })
def is_admin(user):
    return user.groups.filter(name='subbu').exists()

def index(request):
    return render(request,'library/home.html')
@login_required(login_url='/adminlogin')
@user_passes_test(is_admin)
def add_book(request):
    if request.method == "POST":
        bk = BookForm(request.POST)
        if bk.is_valid():
            bk.save()
            return HttpResponseRedirect('/adminpage')
        else:
            bk=BookForm()
            return render(request, 'library/add_books.html',{'form':bk})
    bk = BookForm()
    return render(request, 'library/add_books.html',{'form':bk}) 

def edit_book(request,id):
    if request.method == "POST":
        book = Books.objects.get(pk=id)
        fm = BookForm(request.POST,instance=book)
        if fm.is_valid():
            fm.save()
            return redirect('/adminpage')
    book = Books.objects.get(pk=id)
    fm = BookForm(instance=book)
    return render(request,'library/edit_book.html',{'form':fm})   

def student_register(request):
    if request.method == 'POST':
        fm = StudentForm(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            pa = fm.cleaned_data['password']
            reg = Student(name=nm,email=em,password=pa)
            reg.save()
            return HttpResponseRedirect('/login')
    else:
        fm = StudentForm()
        return render(request, 'library/student_register.html',{'form':fm})
    fm = StudentForm()
    return render(request, 'library/student_register.html',{'form':fm})

def view_students(request):
    st = Student.objects.all()
    return render(request, 'library/users.html',{'students':st})

def edit_user(request,id):
    if request.method == "POST":
        user = Student.objects.get(pk=id)
        fm = StudentForm(request.POST,instance=user)
        if fm.is_valid():
            fm.save()
            return redirect('/users')
    user = Student.objects.get(pk=id)
    fm = StudentForm(instance=user)
    return render(request,'library/edit_user.html',{'form':fm}) 


@login_required(login_url='/adminlogin')
@user_passes_test(is_admin)
def adminpage(request):
    bk = Books.objects.all()
    return render(request, 'library/adminpage.html',{'books':bk})

def user_login(request):
    if request.method == 'POST':
        fm = LoginForm(request.POST)
        if fm.is_valid():
            em = fm.cleaned_data['email']
            pw = fm.cleaned_data['password']
            user = authenticate(request, username=em,password=pw)
            print(user)
            if user is not None:
                login(request,user)
                return redirect('/studentview')
            fm=LoginForm()
            return render(request, 'library/login.html',{'form':fm})
    fm = LoginForm()
    return render(request, 'library/login.html',{'form':fm})

def user_logout(request):
    logout(request)
    return redirect('/login')

def delete_book(request,id):
    if request.method == "POST":
        bk = Books.objects.get(pk=id)
        bk.delete()
        return HttpResponseRedirect('/adminpage')

def delete_user(request,id):
    if request.method == "POST":
        st = Student.objects.get(pk=id)
        st.delete()
        return HttpResponseRedirect('/users')

def admin_login(request):
    if request.method == 'POST':
        fm = LoginForm(request.POST)
        if fm.is_valid():
            return render(request, 'library/adminlogin.html',{'form':fm})
    else:
        fm = LoginForm()
        return render(request, 'library/adminlogin.html',{'form':fm})
    fm = LoginForm()
    return render(request, 'library/adminlogin.html',{'form':fm})

@login_required(login_url='/')
def student_view(request):
    return render(request, 'library/index.html',{'books':Books.objects.all()})