from django.urls import path
from library import views

urlpatterns = [
    path('',views.index,name='index'),
    path('login/',views.user_login,name='user_login'),
    path('logout/',views.user_logout,name='user_logout'),
    path('register/',views.student_register,name='user_register'),
    path('users/',views.view_users,name='view_users'),
    path('adminpage/',views.adminpage,name='adminpage'),
    path('deletebook/<int:id>/',views.delete_book,name='deletebook'),
    path('deleteuser/<int:id>/',views.delete_user,name='deleteuser'),
    path('edituser/<int:id>/',views.edit_user,name='edituser'),
    path('adminlogin/',views.admin_login,name='admin_login'),
    path('studentview/',views.student_view,name='student_view'),
    path('addbooks/',views.add_book,name="add_book"),
    path('editbook/<str:id>/',views.edit_book,name='editbook'),
    ]
