from django.http import HttpResponseRedirect
from django.shortcuts import render,redirect
from .models import Books
from .forms import BookForm, LoginForm, RegistrationForm
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib import messages

#default home page
def index(request):
    return render(request,'library/home.html')

# function to add book in db
@login_required(login_url='/adminlogin')
def add_book(request):
    if request.method == "POST":
        bk = BookForm(request.POST)
        if bk.is_valid():
            bk.save()
            return HttpResponseRedirect('/adminpage')
        else:
            bk=BookForm()
            return render(request, 'library/add_books.html',{'form':bk})
    bk = BookForm()
    return render(request, 'library/add_books.html',{'form':bk}) 

# function edit book
@login_required(login_url='/adminlogin')
def edit_book(request,id):
    if request.method == "POST":
        book = Books.objects.get(pk=id)
        fm = BookForm(request.POST,instance=book)
        if fm.is_valid():
            fm.save()
            return redirect('/adminpage')
    book = Books.objects.get(pk=id)
    fm = BookForm(instance=book)
    return render(request,'library/edit_book.html',{'form':fm})   

# function to register student in db
def student_register(request):
    if request.method == 'POST':
        fm = RegistrationForm(request.POST)
        print(fm)
        print(fm.is_valid())
        if fm.is_valid() is True:
            fm.save()
            messages.success(request,"Student registered successfully")
            return HttpResponseRedirect('/login')
                
        else:
            usr = fm.cleaned_data['username']
            print(usr)
            usr_obj=User.objects.filter(username=usr)
            print(usr_obj)
            messages.warning(request,'student already exits')
            return HttpResponseRedirect('/login')
    else:
        fm = RegistrationForm()
        return render(request, 'library/student_register.html',{'form':fm})

# function to view all the user registered in db
@login_required(login_url='/adminlogin')
def view_users(request):
    if request.user.is_superuser:
        us = User.objects.all()
        return render(request, 'library/users.html',{'users':us})
    else:
        return redirect('/adminlogin')

 # function to edit registered users       
@login_required(login_url='/adminlogin')
def edit_user(request,id):
    if request.user.is_superuser:
        if request.method == "POST":
            user = User.objects.get(pk=id)
            fm = RegistrationForm(request.POST,instance=user)
            if fm.is_valid():
                fm.save()
                return redirect('/users')
        user = User.objects.get(pk=id)
        fm = RegistrationForm(instance=user)
        return render(request,'library/edit_user.html',{'form':fm}) 
    else:
        return redirect('/adminlogin')

# function to render adminpage
@login_required(login_url='/adminlogin')
def adminpage(request):
    if request.user.is_superuser:
        bk = Books.objects.all()
        return render(request, 'library/adminpage.html',{'books':bk})
    else:
       return redirect('/adminlogin')

# function for login
def user_login(request):
    if request.method == 'POST':
        fm = LoginForm(request.POST)
        print(fm)
        if fm.is_valid():
            us = fm.cleaned_data['name']
            pw = fm.cleaned_data['password']
            print(us,pw)
            user = authenticate(request, username=us,password=pw)
            print(user)
            if user is not None:
                login(request,user)
                return redirect('/studentview')
            fm=LoginForm()
            return render(request, 'library/login.html',{'form':fm})
    fm = LoginForm()
    return render(request, 'library/login.html',{'form':fm})

# function for logout
def user_logout(request):
    logout(request)
    return redirect('/')

# function to delete a book in db
@login_required(login_url='/login')
def delete_book(request,id):
    if request.method == "POST":
        bk = Books.objects.get(pk=id)
        bk.delete()
        return HttpResponseRedirect('/adminpage')

# function to remove users from db
@login_required(login_url='/login')
def delete_user(request,id):
    if request.method == "POST":
        st = User.objects.get(pk=id)
        st.delete()
        return HttpResponseRedirect('/users')

# function to render admin page
def admin_login(request):
    if request.method == 'POST':
        fm = LoginForm(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            pas = fm.cleaned_data['password']
            user = authenticate(request,username=nm,password=pas)
            if user is not None:
              login(request,user)
              return redirect('/adminpage')
    else:
        fm = LoginForm()
        return render(request, 'library/adminlogin.html',{'form':fm})
    fm = LoginForm()
    return render(request, 'library/adminlogin.html',{'form':fm})

# function to show all books in db
@login_required(login_url='/login')
def student_view(request):
    return render(request, 'library/index.html',{'books':Books.objects.all()})
