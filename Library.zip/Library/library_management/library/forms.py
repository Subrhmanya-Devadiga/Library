from django import forms
from django.contrib.auth.models import User
from .models import Books, Login
from django.contrib.auth.forms import UserCreationForm


class LoginForm(forms.ModelForm):
    class Meta:
        model = Login
        fields = ['name','password']
        widgets = {
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'password':forms.PasswordInput(attrs={'class':'form-control'}),
        }        


class BookForm(forms.ModelForm):
    class Meta:
        model = Books
        fields = ['title','author','quantity']
        widgets = {
            'title':forms.TextInput(attrs={'class':'form-control'}),
            'author':forms.TextInput(attrs={'class':'form-control'}),
            'quantity':forms.TextInput(attrs={'class':'form-control'}),
        }

class RegistrationForm(UserCreationForm):
    
        username = forms.CharField(widget=forms.TextInput(attrs={"class":'form-control','placeholder':'enter username','type':'text'}))
        email = forms.CharField(widget=forms.TextInput(attrs={"class":'form-control','placeholder':'enter email-id','type':'email'}))
        password1 = forms.CharField(widget=forms.TextInput(attrs={"class":'form-control','placeholder':'enter password','type':'password'}))
        password2 = forms.CharField(widget=forms.TextInput(attrs={"class":'form-control','placeholder':'re-enter password','type':'password'}))
        class Meta:       
            model = User
            fields = ['username','email','password1','password2']











