from django.db import models


class Books(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    quantity = models.IntegerField()

    def __str__(self):
        return f'{self.title} {self.author}'

class Login(models.Model):
    name = models.CharField(max_length=100)
    password = models.CharField(max_length=100)

    def __str__(self):
        return f'{self.name} {self.email}'

    